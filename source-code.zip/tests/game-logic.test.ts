import { test } from 'node:test';
import assert from 'node:assert/strict';
import { chooseUpgrades } from '../src/roguelike/Upgrades.ts';
import { SkillBook } from '../src/skills/SkillBook.ts';
import { loadLives, saveLife, type LifeRecord } from '../src/data/LifeArchive.ts';

test('成长选项抽取三个不同条目，且不修改原数组', () => {
  const options = Array.from({ length: 5 }, (_, index) => ({
    name: `选项 ${index}`, description: '', apply: () => {},
  }));
  const choices = chooseUpgrades(options);
  assert.equal(choices.length, 3);
  assert.equal(new Set(choices).size, 3);
  assert.equal(options.length, 5);
  assert.ok(choices.every(choice => options.includes(choice)));
});

test('加权选项不会在同一次升级中重复出现', () => {
  const weighted = { name: '雷引诀', description: '', apply: () => {} };
  const choices = chooseUpgrades([weighted, weighted, { name: '凝剑', description: '', apply: () => {} }, { name: '回春', description: '', apply: () => {} }]);
  assert.equal(choices.length, 3);
  assert.equal(new Set(choices.map(choice => choice.name)).size, 3);
});

test('功法升级不会超过最高等级，且互不影响', () => {
  const book = new SkillBook();
  book.upgrade('fire');
  book.upgrade('fire');
  book.upgrade('fire');
  assert.equal(book.level('fire'), 2);
  assert.equal(book.level('sword'), 0);
});

test('人生档案保存、读取，并保护损坏的数据', () => {
  const values = new Map<string, string>();
  const storage = {
    getItem: (key: string) => values.get(key) ?? null,
    setItem: (key: string, value: string) => { values.set(key, value); },
  };
  Object.defineProperty(globalThis, 'localStorage', { value: storage, configurable: true });
  try {
    const record: LifeRecord = { result: '此世已终', cause: '妖兽围攻', realm: '凡人', fate: '聚灵之体', root: '火灵根', kills: 3, skills: '烈火 1', seconds: 30 };
    assert.deepEqual(loadLives(), []);
    assert.equal(saveLife(record), 1);
    assert.equal(saveLife(record), 2);
    assert.deepEqual(loadLives(), [record, record]);
    storage.setItem('cheng-buliao-xian-lives-v1', '{损坏');
    assert.equal(loadLives(), null);
    assert.equal(saveLife(record), null);
    assert.equal(storage.getItem('cheng-buliao-xian-lives-v1'), '{损坏');
  } finally {
    delete (globalThis as { localStorage?: unknown }).localStorage;
  }
});

# 成不了仙

2D 竖屏实时动作肉鸽修仙游戏。目前可从主菜单进入战场，移动、自动攻击妖兽、靠近拾取灵气并在升级时三选一；灵气会在战斗时间 20 秒后消散。已加入飞剑、雷引、烈火和部分修仙系统原型。死亡后可重新开始。详见 [项目总纲](PROJECT_MASTER.md)。

按空格或点击右下角「剑气斩」释放范围技能；按 P 或点击左侧按钮暂停和继续。新增寒冰诀可减速敌人，并与雷引、剑气斩联动。精英与 Boss 原型已加入，Boss 机制尚待实战验收。

V0.6 加入命格、灵根、天道关注与炼气突破原型，相关平衡及突破流程尚待验收。

V0.7 初步加入战斗中途的前路选择、灵石、坊市、古庙事件与秘境精英挑战；完整路线和装备背包尚未实现。

V0.8 结算会将人生档案保存在当前浏览器本地，可从战斗或结算界面浏览；完成两世解锁轮回残魂命格。记录按浏览器来源（包括端口）隔离，清除站点数据会删除记录。

启动本地服务后使用终端显示的地址；Windows PowerShell 中可用 `$env:NODE_OPTIONS='--max-old-space-size=4096'; npm run build` 执行较大内存的构建。

需要 Node.js 22.12+ 和 npm（推荐 Node.js 22 LTS，版本见 `.nvmrc`）。Windows PowerShell 中在项目根目录执行：

```powershell
npm ci
npm run dev
```

在浏览器打开终端显示的本地地址（默认 http://localhost:5173/）。生产构建执行 `npm run build`，产物位于 `dist/`；`npm run preview` 可本地预览。发布时将 dist 内容部署到支持静态文件的 Web 服务器，手机访问需设备可连接服务器；平台封装尚未实现。

执行 `npm test` 运行 Node 内置自动化测试，`npm run typecheck` 检查类型，`npm run check` 依次运行测试和生产构建。测试覆盖部分独立游戏逻辑，不代替浏览器和手机实测。

Git 仓库当前尚无提交。提交前需配置作者身份，例如 `git config --local user.name "姓名"` 和 `git config --local user.email "邮箱"`；之后可检查 `git status` 并创建首次提交。

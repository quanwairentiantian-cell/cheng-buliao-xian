import Phaser from 'phaser';
import { Enemy } from '../entities/Enemy';

export class Projectile {
  readonly radius = 8;
  private readonly marker: Phaser.GameObjects.Arc;
  private readonly velocity: Phaser.Math.Vector2;
  private remaining = 1800;
  private readonly hitEnemies = new Set<Enemy>();
  private remainingHits: number;

  constructor(scene: Phaser.Scene, x: number, y: number, targetX: number, targetY: number, pierce = 0) {
    this.marker = scene.add.circle(x, y, this.radius, 0x9be6ed);
    this.velocity = new Phaser.Math.Vector2(targetX - x, targetY - y).normalize().scale(480);
    this.remainingHits = 1 + pierce;
  }

  get x(): number { return this.marker.x; }
  get y(): number { return this.marker.y; }

  canHit(enemy: Enemy): boolean { return !this.hitEnemies.has(enemy); }
  hit(enemy: Enemy): boolean {
    this.hitEnemies.add(enemy);
    return --this.remainingHits <= 0;
  }

  update(delta: number): boolean {
    const elapsed = Math.min(delta, 50);
    this.marker.x += this.velocity.x * elapsed / 1000;
    this.marker.y += this.velocity.y * elapsed / 1000;
    this.remaining -= elapsed;
    return this.remaining > 0;
  }

  destroy(): void { this.marker.destroy(); }
}

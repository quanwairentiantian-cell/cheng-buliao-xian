export type SkillId = 'sword' | 'lightning' | 'fire' | 'ice';

export const skillData: Record<SkillId, { name: string; descriptions: string[] }> = {
  sword: { name: '飞剑诀', descriptions: ['飞剑穿透一名敌人', '飞剑再穿透一名敌人'] },
  lightning: { name: '雷引诀', descriptions: ['命中时雷击附近一名敌人', '雷击可连锁两名附近敌人'] },
  fire: { name: '烈火诀', descriptions: ['命中使敌人燃烧，持续造成伤害', '燃烧敌人死亡时灼伤附近敌人'] },
  ice: { name: '寒冰诀', descriptions: ['命中使敌人减速 40%', '减速持续更久，剑气斩冻结敌人'] },
};

export class SkillBook {
  private levels: Record<SkillId, number> = { sword: 0, lightning: 0, fire: 0, ice: 0 };

  level(id: SkillId): number { return this.levels[id]; }
  upgrade(id: SkillId): void { this.levels[id] = Math.min(this.levels[id] + 1, skillData[id].descriptions.length); }
}

export interface LifeRecord {
  result: string;
  cause: string;
  realm: string;
  fate: string;
  root: string;
  kills: number;
  skills: string;
  seconds: number;
}

const storageKey = 'cheng-buliao-xian-lives-v1';

export function loadLives(): LifeRecord[] | null {
  try {
    const raw = localStorage.getItem(storageKey);
    const records: unknown = raw ? JSON.parse(raw) : [];
    if (!Array.isArray(records) || !records.every(record => record && typeof record === 'object' && typeof record.result === 'string' && typeof record.cause === 'string' && typeof record.realm === 'string' && typeof record.fate === 'string' && typeof record.root === 'string' && typeof record.skills === 'string' && typeof record.kills === 'number' && typeof record.seconds === 'number')) return null;
    return records as LifeRecord[];
  } catch {
    return null;
  }
}

export function saveLife(record: LifeRecord): number | null {
  try {
    const previous = loadLives();
    if (!previous) return null;
    const records = [...previous, record];
    localStorage.setItem(storageKey, JSON.stringify(records));
    return records.length;
  } catch {
    return null;
  }
}

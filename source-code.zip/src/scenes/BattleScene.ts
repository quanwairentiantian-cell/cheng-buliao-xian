import Phaser from 'phaser';
import { Player } from '../entities/Player';
import { VirtualJoystick } from '../input/VirtualJoystick';
import { Enemy } from '../entities/Enemy';
import { Projectile } from '../combat/Projectile';
import { Spirit } from '../entities/Spirit';
import { chooseUpgrades } from '../roguelike/Upgrades';
import { SkillBook, skillData, type SkillId } from '../skills/SkillBook';
import { Cultivation } from '../cultivation/Cultivation';
import { loadLives, saveLife } from '../data/LifeArchive';

export class BattleScene extends Phaser.Scene {
  private player!: Player;
  private joystick!: VirtualJoystick;
  private enemies: Enemy[] = [];
  private projectiles: Projectile[] = [];
  private spirits: Spirit[] = [];
  private skills = new SkillBook();
  private skillStatus!: Phaser.GameObjects.Text;
  private cultivation = new Cultivation();
  private cultivationStatus!: Phaser.GameObjects.Text;
  private trialRemaining = 0;
  private nextTrialAt = 0;
  private bossStatus!: Phaser.GameObjects.Text;
  private activeButton!: Phaser.GameObjects.Text;
  private activeReadyAt = 0;
  private invulnerableUntil = 0;
  private bossSpawned = false;
  private routeChosen = false;
  private secretElite?: Enemy;
  private nextBossAttack = 0;
  private warning?: { marker: Phaser.GameObjects.Arc; x: number; y: number; expires: number; radius: number; trial: boolean };
  private battleTime = 0;
  private level = 1;
  private experience = 0;
  private experienceNeeded = 3;
  private attackDamage = 1;
  private attackInterval = 550;
  private pickupRadius = 45;
  private choosing = false;
  private nextSpawn = 0;
  private nextAttack = 0;
  private kills = 0;
  private stones = 0;
  private ended = false;
  private paused = false;
  private status!: Phaser.GameObjects.Text;
  private pauseButton!: Phaser.GameObjects.Text;
  private keys!: Record<'up' | 'down' | 'left' | 'right' | 'w' | 'a' | 's' | 'd', Phaser.Input.Keyboard.Key>;

  constructor() { super('BattleScene'); }

  create(): void {
    this.enemies = [];
    this.projectiles = [];
    this.spirits = [];
    this.skills = new SkillBook();
    this.cultivation = new Cultivation(loadLives()?.length ?? 0);
    this.trialRemaining = 0;
    this.nextTrialAt = 0;
    this.activeReadyAt = 0;
    this.invulnerableUntil = 0;
    this.bossSpawned = false;
    this.routeChosen = false;
    this.secretElite = undefined;
    this.nextBossAttack = 0;
    this.warning = undefined;
    this.battleTime = 0;
    this.level = 1;
    this.experience = 0;
    this.experienceNeeded = 3;
    this.attackDamage = 1;
    this.attackInterval = 550;
    this.pickupRadius = 45;
    this.choosing = false;
    this.nextSpawn = 0;
    this.nextAttack = 0;
    this.kills = 0;
    this.stones = 0;
    this.ended = false;
    this.paused = false;
    const { width, height } = this.scale;
    const ground = this.add.graphics();
    ground.fillStyle(0x1b3029).fillRect(0, 0, width, height);
    ground.lineStyle(1, 0x597060, 0.13);
    for (let x = 0; x <= width; x += 120) ground.lineBetween(x, 0, x, height);
    for (let y = 0; y <= height; y += 120) ground.lineBetween(0, y, width, y);
    ground.lineStyle(2, 0xa38d60, 0.25).strokeCircle(width / 2, height / 2, 240).strokeCircle(width / 2, height / 2, 258);
    ground.lineBetween(width / 2 - 258, height / 2, width / 2 + 258, height / 2);
    ground.lineBetween(width / 2, height / 2 - 258, width / 2, height / 2 + 258);
    ground.fillStyle(0x0b1716, 0.9).fillRect(0, 0, width, 215);
    ground.lineStyle(2, 0x927e51, 0.8).strokeRect(5, 5, width - 10, height - 10).lineBetween(24, 210, width - 24, 210);
    this.add.text(width / 2, 38, '✦  成不了仙  ✦', { fontFamily: 'serif', fontSize: '29px', color: '#e4d0a0' }).setOrigin(0.5);
    this.status = this.add.text(width / 2, 90, '', { fontFamily: 'sans-serif', fontSize: '20px', color: '#f5dfaa', align: 'center' }).setOrigin(0.5);
    this.cultivationStatus = this.add.text(width / 2, 130, '', { fontFamily: 'sans-serif', fontSize: '21px', color: '#a7b9ae' }).setOrigin(0.5);
    this.skillStatus = this.add.text(width / 2, 165, '', { fontFamily: 'sans-serif', fontSize: '22px', color: '#a9dcd1' }).setOrigin(0.5);
    this.bossStatus = this.add.text(width / 2, 200, '', { fontFamily: 'sans-serif', fontSize: '25px', color: '#ffb8a8' }).setOrigin(0.5);
    this.pauseButton = this.add.text(18, 225, '暂停', { fontFamily: 'sans-serif', fontSize: '22px', color: '#fff0c7', backgroundColor: '#40584d', padding: { x: 14, y: 8 } }).setInteractive({ useHandCursor: true });
    this.pauseButton.on('pointerdown', () => this.togglePause());
    this.activeButton = this.add.text(width - 110, height - 130, '剑气斩\n空格', { fontFamily: 'sans-serif', fontSize: '25px', color: '#fff0c7', backgroundColor: '#536a59', align: 'center', padding: { x: 18, y: 16 } }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    this.activeButton.on('pointerdown', () => this.castActiveSkill());
    this.add.text(width - 15, 225, '人生档案', { fontFamily: 'sans-serif', fontSize: '22px', color: '#dbc493', backgroundColor: '#40584d', padding: { x: 12, y: 8 } }).setOrigin(1, 0).setInteractive({ useHandCursor: true }).on('pointerdown', () => {
      if (!this.choosing && !this.ended) this.showArchive();
    });
    this.add.text(width - 15, 275, '轮回图鉴', { fontFamily: 'sans-serif', fontSize: '22px', color: '#dbc493', backgroundColor: '#40584d', padding: { x: 12, y: 8 } }).setOrigin(1, 0).setInteractive({ useHandCursor: true }).on('pointerdown', () => {
      if (!this.choosing && !this.ended) this.showCodex();
    });
    this.player = new Player(this, width / 2, height / 2);
    if (this.cultivation.fate === '聚灵之体') this.pickupRadius += 25;
    if (this.cultivation.fate === '轮回残魂') this.stones = 3;
    this.joystick = new VirtualJoystick(this);
    this.keys = this.input.keyboard!.addKeys({ up: 'UP', down: 'DOWN', left: 'LEFT', right: 'RIGHT', w: 'W', a: 'A', s: 'S', d: 'D' }) as typeof this.keys;
    const activeKey = this.input.keyboard!.addKey(Phaser.Input.Keyboard.KeyCodes.SPACE);
    activeKey.on('down', this.castActiveSkill, this);
    const pauseKey = this.input.keyboard!.addKey(Phaser.Input.Keyboard.KeyCodes.P);
    pauseKey.on('down', this.togglePause, this);
    if (this.cultivation.fate === '天生道体') this.attackInterval = 500;
    this.updateStatus();
  }

  update(_time: number, delta: number): void {
    if (this.ended || this.choosing || this.paused) return;
    this.battleTime += Math.min(delta, 50);
    const time = this.battleTime;
    if (!this.routeChosen && time >= 25000) {
      this.routeChosen = true;
      this.showRoute();
      return;
    }
    this.activeButton.setText(time >= this.activeReadyAt ? '剑气斩\n空格' : `剑气斩\n${Math.ceil((this.activeReadyAt - time) / 1000)}秒`);
    const k = this.keys;
    const keyboard = new Phaser.Math.Vector2(Number(k.right.isDown || k.d.isDown) - Number(k.left.isDown || k.a.isDown), Number(k.down.isDown || k.s.isDown) - Number(k.up.isDown || k.w.isDown));
    const direction = keyboard.lengthSq() ? keyboard.normalize() : this.joystick.direction;
    this.player.move(direction, delta, this.scale.width, this.scale.height);
    if (!this.bossSpawned && time >= 45000) {
      this.bossSpawned = true;
      this.spawnEnemy('boss');
      this.nextBossAttack = time + 3000;
    }
    const boss = this.enemies.find(enemy => enemy.kind === 'boss');
    if (this.cultivation.breakthrough && !this.warning && time >= this.nextTrialAt && this.trialRemaining > 0) {
      const x = this.player.x;
      const y = this.player.y;
      const radius = 90;
      const marker = this.add.circle(x, y, radius, 0xffde70, 0.3).setStrokeStyle(4, 0xffde70);
      this.warning = { marker, x, y, radius, expires: time + 1300, trial: true };
      this.trialRemaining--;
    }
    if (boss) this.bossStatus.setText(`妖王 ${Math.max(0, boss.health)}/45 · ${boss.health <= 22 ? '狂暴' : '第一阶段'}`);
    if (boss && !this.warning && time >= this.nextBossAttack) {
      const radius = boss.health <= 22 ? 150 : 110;
      const x = this.player.x;
      const y = this.player.y;
      const marker = this.add.circle(x, y, radius, 0xef4639, 0.25).setStrokeStyle(4, 0xff6b53);
      this.warning = { marker, x, y, radius, expires: time + 1400, trial: false };
    }
    if (this.warning && time >= this.warning.expires) {
      if (Phaser.Math.Distance.Between(this.player.x, this.player.y, this.warning.x, this.warning.y) <= this.warning.radius + this.player.radius) {
        this.player.takeDamage(25);
        this.updateStatus();
      }
      const trial = this.warning.trial;
      this.warning.marker.destroy();
      this.warning = undefined;
      if (this.player.health <= 0) { this.finish(false, trial ? '突破天雷' : '妖王法术'); return; }
      if (trial && this.cultivation.breakthrough) {
        if (this.trialRemaining === 0) {
          this.cultivation.breakthrough = false;
          this.cultivation.realm = '炼气';
          this.cultivation.addAttention(10);
          this.attackDamage += this.cultivation.fate === '逆天而行' ? 2 : 1;
          this.updateStatus();
        } else this.nextTrialAt = time + 700;
      }
      if (!trial) this.nextBossAttack = time + (boss && boss.health <= 22 ? 2200 : 3500);
    }
    if (time >= this.nextSpawn && this.enemies.length < 40) {
      const kinds: Array<'normal' | 'fast' | 'heavy' | 'elite' | 'special'> = time >= 20000 ? ['normal', 'fast', 'heavy', 'elite', 'special'] : time >= 8000 ? ['normal', 'fast', 'heavy', 'special'] : ['normal'];
      this.spawnEnemy(Phaser.Utils.Array.GetRandom(kinds));
      this.nextSpawn = time + (this.cultivation.attention >= 20 ? 1350 : 1700);
    }
    if (time >= this.nextAttack && this.enemies.length > 0) {
      const target = this.enemies.reduce((nearest, enemy) =>
        Phaser.Math.Distance.Squared(this.player.x, this.player.y, enemy.x, enemy.y) < Phaser.Math.Distance.Squared(this.player.x, this.player.y, nearest.x, nearest.y) ? enemy : nearest);
      this.projectiles.push(new Projectile(this, this.player.x, this.player.y, target.x, target.y, this.skills.level('sword')));
      this.nextAttack = time + this.attackInterval;
    }
    for (const enemy of [...this.enemies]) {
      if (!this.enemies.includes(enemy)) continue;
      if (enemy.updateBurn(time)) {
        this.strike(enemy, 1);
        if (!this.enemies.includes(enemy)) continue;
      }
      enemy.chase(this.player.x, this.player.y, delta, time);
      if (time >= this.invulnerableUntil && time >= enemy.nextContactAt && Phaser.Math.Distance.Between(enemy.x, enemy.y, this.player.x, this.player.y) < enemy.radius + this.player.radius) {
        this.player.takeDamage(10);
        this.invulnerableUntil = time + 700;
        enemy.nextContactAt = time + 1000;
        this.updateStatus();
        if (this.player.health <= 0) { this.finish(false, '妖兽围攻'); return; }
      }
    }
    for (const projectile of [...this.projectiles]) {
      const alive = projectile.update(delta);
      const enemy = this.enemies.find(candidate => projectile.canHit(candidate) && Phaser.Math.Distance.Between(projectile.x, projectile.y, candidate.x, candidate.y) < projectile.radius + candidate.radius);
      let spent = false;
      if (enemy) {
        spent = projectile.hit(enemy);
        if (this.skills.level('fire') > 0) enemy.ignite(time);
        if (this.skills.level('ice') > 0) enemy.chill(time, this.skills.level('ice') === 2 ? 3500 : 1800);
        this.chainLightning(enemy);
        if (!this.ended && this.enemies.includes(enemy)) this.strike(enemy, this.attackDamage + (this.cultivation.fate === '天煞孤星' && this.enemies.filter(other => other !== enemy && Phaser.Math.Distance.Between(this.player.x, this.player.y, other.x, other.y) < 150).length === 0 ? 1 : 0));
      }
      if (this.ended) return;
      if (spent || !alive || projectile.x < 0 || projectile.x > this.scale.width || projectile.y < 0 || projectile.y > this.scale.height) {
        projectile.destroy();
        this.projectiles.splice(this.projectiles.indexOf(projectile), 1);
      }
    }
    for (const spirit of [...this.spirits]) {
      if (!spirit.update(time)) {
        spirit.destroy();
        this.spirits.splice(this.spirits.indexOf(spirit), 1);
        continue;
      }
      if (Phaser.Math.Distance.Between(this.player.x, this.player.y, spirit.x, spirit.y) <= this.pickupRadius) {
        spirit.destroy();
        this.spirits.splice(this.spirits.indexOf(spirit), 1);
        this.experience++;
        if (this.experience >= this.experienceNeeded) {
          this.experience -= this.experienceNeeded;
          this.level++;
          if (this.level === 3 && this.cultivation.realm === '凡人') {
            this.cultivation.breakthrough = true;
            this.trialRemaining = 3;
            this.nextTrialAt = time + 2500;
          }
          this.experienceNeeded += 2;
          this.updateStatus();
          this.showUpgrades();
          return;
        }
        this.updateStatus();
      }
    }
  }

  private strike(enemy: Enemy, damage: number): void {
    if (this.ended || !this.enemies.includes(enemy)) return;
    enemy.health -= damage;
    if (enemy.health <= 0) {
      const burning = enemy.burnUntil > this.battleTime;
      const x = enemy.x;
      const y = enemy.y;
      this.spirits.push(new Spirit(this, enemy.x, enemy.y, this.battleTime));
      enemy.destroy();
      this.enemies.splice(this.enemies.indexOf(enemy), 1);
      if (enemy.kind === 'boss' && this.warning && !this.warning.trial) {
        this.warning.marker.destroy();
        this.warning = undefined;
      }
      this.kills++;
      if (enemy === this.secretElite) {
        this.pickupRadius += 40;
        this.secretElite = undefined;
      }
      this.stones += enemy.kind === 'elite' ? 3 : 1;
      if (enemy.kind === 'elite' || enemy.kind === 'boss') this.cultivation.addAttention(10);
      this.updateStatus();
      if (burning && this.skills.level('fire') >= 2) {
        const flare = this.add.circle(x, y, 90, 0xff8b36, 0.35);
        this.tweens.add({ targets: flare, alpha: 0, duration: 250, onComplete: () => flare.destroy() });
        for (const nearby of this.enemies) {
          if (Phaser.Math.Distance.Between(x, y, nearby.x, nearby.y) <= 90) nearby.ignite(this.battleTime);
        }
      }
      if (enemy.kind === 'boss') this.finish(true);
    }
  }

  private chainLightning(first: Enemy): void {
    const visited = new Set<Enemy>([first]);
    let current = first;
    for (let index = 0; index < this.skills.level('lightning'); index++) {
      const next = this.enemies.filter(enemy => !visited.has(enemy) && Phaser.Math.Distance.Between(current.x, current.y, enemy.x, enemy.y) <= 180)
        .sort((left, right) => Phaser.Math.Distance.Squared(current.x, current.y, left.x, left.y) - Phaser.Math.Distance.Squared(current.x, current.y, right.x, right.y))[0];
      if (!next) break;
      const bolt = this.add.line(0, 0, current.x, current.y, next.x, next.y, 0xf4e37b).setOrigin(0).setLineWidth(4);
      this.tweens.add({ targets: bolt, alpha: 0, duration: 180, onComplete: () => bolt.destroy() });
      visited.add(next);
      if (this.skills.level('fire') > 0) next.ignite(this.battleTime);
      if (this.skills.level('ice') > 0) next.chill(this.battleTime, this.skills.level('ice') === 2 ? 3500 : 1800);
      this.strike(next, this.attackDamage);
      current = next;
    }
  }

  private spawnEnemy(kind: 'normal' | 'fast' | 'heavy' | 'elite' | 'special' | 'boss' = 'normal'): Enemy {
    const { width, height } = this.scale;
    const edge = Phaser.Math.Between(0, 3);
    const x = edge === 0 ? 22 : edge === 1 ? width - 22 : Phaser.Math.Between(22, width - 22);
    const y = edge === 2 ? 22 : edge === 3 ? height - 22 : Phaser.Math.Between(22, height - 22);
    const enemy = new Enemy(this, x, y, kind);
    this.enemies.push(enemy);
    return enemy;
  }

  private castActiveSkill(): void {
    if (this.ended || this.choosing || this.paused || this.battleTime < this.activeReadyAt) return;
    this.activeReadyAt = this.battleTime + 7000;
    const effect = this.add.circle(this.player.x, this.player.y, 150, 0x9be6ed, 0.25).setStrokeStyle(4, 0xd8fff0);
    this.tweens.add({ targets: effect, alpha: 0, duration: 350, onComplete: () => effect.destroy() });
    for (const enemy of [...this.enemies]) {
      if (Phaser.Math.Distance.Between(this.player.x, this.player.y, enemy.x, enemy.y) <= 150) {
        if (this.skills.level('ice') >= 2) enemy.freeze(this.battleTime, 1200);
        this.strike(enemy, 4);
      }
    }
  }

  private togglePause(): void {
    if (this.ended || this.choosing) return;
    this.paused = !this.paused;
    this.joystick.reset();
    this.pauseButton.setText(this.paused ? '继续' : '暂停');
    if (this.paused) {
      const { width, height } = this.scale;
      this.add.text(width / 2, height / 2, '战斗暂停\n按 P 或点击继续', {
        fontFamily: 'sans-serif', fontSize: '34px', color: '#dbc493', align: 'center',
      }).setOrigin(0.5).setName('pause-overlay').setDepth(90);
    } else {
      this.children.getAll().filter(child => child.name === 'pause-overlay').forEach(child => child.destroy());
    }
  }

  private showRoute(): void {
    this.choosing = true;
    this.joystick.reset();
    const { width, height } = this.scale;
    const overlay = this.add.container(0, 0).setDepth(100);
    overlay.add(this.add.rectangle(width / 2, height / 2, width, height, 0x000000, 0.85).setInteractive());
    overlay.add(this.add.text(width / 2, height / 2 - 250, '选择前路', { fontFamily: 'sans-serif', fontSize: '38px', color: '#dbc493' }).setOrigin(0.5));
    overlay.destroy(true);
    this.showNode('选择前路', [
      { label: '灵石坊市\n购买丹药或法宝', action: () => this.showMarket() },
      { label: '上古秘境\n挑战精英，胜利获得聚灵珠', action: () => { this.secretElite = this.spawnEnemy('elite'); this.cultivation.addAttention(10); this.resumeRoute(); } },
      { label: '古庙借宿\n选择参拜或拆除神像', action: () => this.showTemple() },
    ]);
  }

  private showNode(title: string, choices: Array<{ label: string; action: () => void }>): void {
    const { width, height } = this.scale;
    const overlay = this.add.container(0, 0).setDepth(100);
    overlay.add(this.add.rectangle(width / 2, height / 2, width, height, 0x000000, 0.85).setInteractive());
    overlay.add(this.add.text(width / 2, height / 2 - 250, title, { fontFamily: 'sans-serif', fontSize: '34px', color: '#dbc493' }).setOrigin(0.5));
    choices.forEach((choice, index) => {
      const button = this.add.text(width / 2, height / 2 - 120 + index * 145, choice.label, {
        fontFamily: 'sans-serif', fontSize: '26px', color: '#fff0c7', backgroundColor: '#40584d', align: 'center', fixedWidth: 560, padding: { x: 10, y: 16 },
      }).setOrigin(0.5).setInteractive({ useHandCursor: true });
      button.on('pointerdown', () => { overlay.destroy(true); choice.action(); });
      overlay.add(button);
    });
  }

  private showMarket(): void {
    this.showNode(`灵石坊市 · 持有 ${this.stones}`, [
      { label: '回春丹：5 灵石\n恢复 40 点生命', action: () => { if (this.stones < 5) { this.showMarket(); return; } this.stones -= 5; this.player.health = Math.min(this.player.maxHealth, this.player.health + 40); this.resumeRoute(); } },
      { label: '聚灵珠：8 灵石\n拾取范围 +40', action: () => { if (this.stones < 8) { this.showMarket(); return; } this.stones -= 8; this.pickupRadius += 40; this.resumeRoute(); } },
      { label: '离开坊市', action: () => this.resumeRoute() },
    ]);
  }

  private showTemple(): void {
    this.showNode('古庙借宿', [
      { label: '参拜神像\n恢复 20 点生命', action: () => { this.player.health = Math.min(this.player.maxHealth, this.player.health + 20); this.resumeRoute(); } },
      { label: '拆除神像\n获得 8 灵石，天道关注 +10', action: () => { this.stones += 8; this.cultivation.addAttention(10); this.resumeRoute(); } },
      { label: '直接离开', action: () => this.resumeRoute() },
    ]);
  }

  private resumeRoute(): void {
    this.updateStatus();
    this.choosing = false;
  }

  private showArchive(): void {
    const wasEnded = this.ended;
    this.choosing = true;
    this.joystick.reset();
    const records = loadLives();
    let index = records ? records.length - 1 : -1;
    const { width, height } = this.scale;
    const overlay = this.add.container(0, 0).setDepth(200);
    overlay.add(this.add.rectangle(width / 2, height / 2, width, height, 0x000000, 0.94).setInteractive());
    const content = this.add.text(width / 2, height / 2 - 80, '', { fontFamily: 'sans-serif', fontSize: '28px', color: '#dbc493', align: 'center', lineSpacing: 12 }).setOrigin(0.5);
    overlay.add(content);
    const render = () => {
      if (!records) { content.setText('档案读取失败'); return; }
      if (index < 0) { content.setText('暂无人生档案'); return; }
      const life = records[index];
      content.setText(`人生档案 · 第 ${index + 1} 世\n${life.result} · ${life.cause}\n${life.realm} · ${life.fate} · ${life.root}\n${life.skills}\n击败 ${life.kills} · 战斗 ${life.seconds} 秒`);
    };
    const addButton = (x: number, label: string, action: () => void) => {
      const button = this.add.text(x, height / 2 + 170, label, { fontFamily: 'sans-serif', fontSize: '27px', color: '#fff0c7', backgroundColor: '#40584d', padding: { x: 15, y: 12 } }).setOrigin(0.5).setInteractive({ useHandCursor: true });
      button.on('pointerdown', action);
      overlay.add(button);
    };
    addButton(width / 2 - 180, '上一世', () => { if (index > 0) { index--; render(); } });
    addButton(width / 2, '关闭', () => { overlay.destroy(true); this.choosing = false; if (!wasEnded) this.updateStatus(); });
    addButton(width / 2 + 180, '下一世', () => { if (records && index < records.length - 1) { index++; render(); } });
    render();
  }

  private showCodex(): void {
    this.choosing = true;
    this.joystick.reset();
    const records = loadLives();
    if (!records) {
      this.choosing = false;
      this.showNode('图鉴读取失败', [{ label: '关闭', action: () => this.resumeRoute() }]);
      this.choosing = true;
      return;
    }
    const fates = [...new Set(records.map(record => record.fate))];
    const roots = [...new Set(records.map(record => record.root))];
    const skills = [...new Set(records.flatMap(record => record.skills.split(' / ').filter(skill => !skill.endsWith(' 0')).map(skill => skill.replace(/\s+\d+$/, ''))))];
    const { width, height } = this.scale;
    const overlay = this.add.container(0, 0).setDepth(200);
    overlay.add(this.add.rectangle(width / 2, height / 2, width, height, 0x000000, 0.94).setInteractive());
    overlay.add(this.add.text(width / 2, height / 2 - 150, `轮回图鉴\n\n命格：${fates.length ? fates.join('、') : '尚未记录'}\n灵根：${roots.length ? roots.join('、') : '尚未记录'}\n功法：${skills.length ? skills.join('、') : '尚未记录'}\n人生档案：${records.length} 世`, { fontFamily: 'sans-serif', fontSize: '28px', color: '#dbc493', align: 'center', lineSpacing: 14 }).setOrigin(0.5));
    overlay.add(this.add.text(width / 2, height / 2 + 180, '关闭', { fontFamily: 'sans-serif', fontSize: '28px', color: '#fff0c7', backgroundColor: '#40584d', padding: { x: 22, y: 12 } }).setOrigin(0.5).setInteractive({ useHandCursor: true }).on('pointerdown', () => { overlay.destroy(true); this.choosing = false; this.updateStatus(); }));
  }

  private updateStatus(): void {
    this.status.setText(`生命 ${this.player.health}/${this.player.maxHealth}  击败 ${this.kills}  等级 ${this.level}  灵气 ${this.experience}/${this.experienceNeeded}\n灵石 ${this.stones}`);
    this.skillStatus.setText(`飞剑 ${this.skills.level('sword')} · 雷引 ${this.skills.level('lightning')} · 烈火 ${this.skills.level('fire')} · 寒冰 ${this.skills.level('ice')}`);
    this.cultivationStatus.setText(`${this.cultivation.breakthrough ? '突破中：躲避三道天雷' : this.cultivation.realm} · ${this.cultivation.fate} · ${this.cultivation.root} · 天道 ${this.cultivation.attention}${this.cultivation.attention >= 20 ? ' 妖兽增多' : ''}`);
  }

  private showUpgrades(): void {
    this.choosing = true;
    this.joystick.reset();
    const { width, height } = this.scale;
    const overlay = this.add.container(0, 0).setDepth(100);
    overlay.add(this.add.rectangle(width / 2, height / 2, width, height, 0x000000, 0.85).setInteractive());
    overlay.add(this.add.text(width / 2, height / 2 - 250, '修为精进 · 选择一项', { fontFamily: 'sans-serif', fontSize: '38px', color: '#dbc493' }).setOrigin(0.5));
    const skillOptions = (['sword', 'lightning', 'fire', 'ice'] as SkillId[]).filter(id => this.skills.level(id) < skillData[id].descriptions.length).map(id => ({
      name: `${skillData[id].name} ${this.skills.level(id) + 1}阶`,
      description: skillData[id].descriptions[this.skills.level(id)],
      apply: () => this.skills.upgrade(id),
    }));
    const preferred = this.cultivation.root === '雷灵根' ? '雷引诀' : '烈火诀';
    const preferredOption = skillOptions.find(option => option.name.startsWith(preferred));
    const options = chooseUpgrades([...skillOptions, ...(preferredOption ? [preferredOption] : []),
      { name: '凝剑', description: '自动攻击伤害 +1', apply: () => { this.attackDamage++; } },
      { name: '疾剑', description: '自动攻击间隔缩短 15%', apply: () => { this.attackInterval = Math.max(150, this.attackInterval * 0.85); } },
      { name: '轻身', description: '移动速度 +30', apply: () => { this.player.speed += 30; } },
      { name: '聚灵', description: '灵气拾取范围 +25', apply: () => { this.pickupRadius += 25; } },
      { name: '回春', description: '恢复 30 点生命', apply: () => { this.player.health = Math.min(this.player.maxHealth, this.player.health + 30); } },
      { name: '养元', description: '恢复 15 点生命，移动速度 +10', apply: () => { this.player.health = Math.min(this.player.maxHealth, this.player.health + 15); this.player.speed += 10; } },
      { name: '剑意', description: '攻击伤害 +1，拾取范围 +10', apply: () => { this.attackDamage++; this.pickupRadius += 10; } },
    ]);
    options.forEach((option, index) => {
      const button = this.add.text(width / 2, height / 2 - 120 + index * 145, `${option.name}\n${option.description}`, {
        fontFamily: 'sans-serif', fontSize: '29px', color: '#fff0c7', backgroundColor: '#40584d',
        align: 'center', fixedWidth: 560, padding: { x: 10, y: 16 },
      }).setOrigin(0.5).setInteractive({ useHandCursor: true });
      button.on('pointerdown', () => {
        if (!this.choosing) return;
        option.apply();
        this.updateStatus();
        overlay.destroy(true);
        this.choosing = false;
      });
      overlay.add(button);
    });
  }

  private finish(victory = false, cause = '妖兽围攻'): void {
    if (this.ended) return;
    this.ended = true;
    this.joystick.reset();
    const skills = `飞剑 ${this.skills.level('sword')} / 雷引 ${this.skills.level('lightning')} / 烈火 ${this.skills.level('fire')} / 寒冰 ${this.skills.level('ice')}`;
    const result = victory ? '妖王已败' : '此世已终';
    const endingCause = victory ? '战胜妖王' : cause;
    const count = saveLife({ result, cause: endingCause, realm: this.cultivation.realm, fate: this.cultivation.fate, root: this.cultivation.root, kills: this.kills, skills, seconds: Math.floor(this.battleTime / 1000) });
    const reward = count === 2 ? '\n解锁命格：轮回残魂（开局获得 3 灵石）' : '';
    const { width, height } = this.scale;
    this.add.rectangle(width / 2, height / 2, width, height, 0x000000, 0.8);
    this.add.text(width / 2, height / 2 - 110, `${result}\n${count === null ? '档案保存失败' : `第 ${count} 世`}\n${this.cultivation.realm} · ${this.cultivation.fate} · ${this.cultivation.root}\n${skills}\n击败 ${this.kills} · 战斗 ${Math.floor(this.battleTime / 1000)} 秒\n${victory ? '结局' : '死因'}：${endingCause}${reward}`, { fontFamily: 'sans-serif', fontSize: '27px', color: '#dbc493', align: 'center', lineSpacing: 12 }).setOrigin(0.5);
    this.add.text(width / 2, height / 2 + 190, '再来一世', { fontFamily: 'sans-serif', fontSize: '36px', color: '#fff0c7', backgroundColor: '#536a59', padding: { x: 28, y: 18 } })
      .setOrigin(0.5).setInteractive({ useHandCursor: true }).on('pointerdown', () => this.scene.restart());
    this.add.text(width / 2, height / 2 + 280, '查看人生档案', { fontFamily: 'sans-serif', fontSize: '28px', color: '#dbc493', backgroundColor: '#40584d', padding: { x: 20, y: 12 } }).setOrigin(0.5).setInteractive({ useHandCursor: true }).on('pointerdown', () => this.showArchive());
  }
}

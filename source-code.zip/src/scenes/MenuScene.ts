import Phaser from 'phaser';

export class MenuScene extends Phaser.Scene {
  constructor() { super('MenuScene'); }

  create(): void {
    const { width, height } = this.scale;
    const art = this.add.graphics();
    art.fillGradientStyle(0x0b1819, 0x0b1819, 0x263c35, 0x263c35).fillRect(0, 0, width, height);
    art.fillStyle(0xb9c69a, 0.09).fillCircle(width / 2, 435, 175);
    art.lineStyle(2, 0xbba26b, 0.3).strokeCircle(width / 2, 435, 200).strokeCircle(width / 2, 435, 210);
    art.fillStyle(0x142724).fillTriangle(0, 825, 220, 500, 390, 825).fillTriangle(250, 825, 520, 470, 720, 825);
    art.fillStyle(0x1c332d).fillTriangle(0, 900, 170, 650, 360, 900).fillTriangle(320, 900, 590, 590, 720, 900);
    art.lineStyle(2, 0xc9ad72, 0.5).strokeRect(30, 30, width - 60, height - 60);
    this.add.text(width / 2, 160, '一  念  入  道', { fontFamily: 'serif', fontSize: '22px', color: '#adbdad', letterSpacing: 5 }).setOrigin(0.5);
    this.add.text(width / 2, 285, '成不了仙', { fontFamily: 'serif', fontSize: '84px', color: '#e9d8a7', stroke: '#17221d', strokeThickness: 6 }).setOrigin(0.5);
    this.add.text(width / 2, 370, '逆天修行，且看这一世。', { fontFamily: 'serif', fontSize: '25px', color: '#b7c7b8' }).setOrigin(0.5);
    const start = this.add.text(width / 2, 840, '开  始  新  的  一  世', {
      fontFamily: 'serif', fontSize: '30px', color: '#f5e7c1', backgroundColor: '#405b4c',
      padding: { x: 42, y: 23 },
    }).setOrigin(0.5).setInteractive({ useHandCursor: true });
    start.on('pointerover', () => start.setStyle({ backgroundColor: '#587460' }));
    start.on('pointerout', () => start.setStyle({ backgroundColor: '#405b4c' }));
    start.on('pointerdown', () => this.scene.start('BattleScene'));
    this.add.text(width / 2, 1010, 'WASD / 方向键或摇杆移动\n空格释放剑气斩  ·  P 暂停\n灵气会逐渐消散，记得及时拾取', {
      fontFamily: 'sans-serif', fontSize: '22px', color: '#aabcae', align: 'center', lineSpacing: 12,
    }).setOrigin(0.5);
    this.add.text(width / 2, 1190, '每一世，都是新的修行', { fontFamily: 'serif', fontSize: '20px', color: '#718b7c' }).setOrigin(0.5);
  }
}

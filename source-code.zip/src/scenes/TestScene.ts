import Phaser from 'phaser';

export class TestScene extends Phaser.Scene {
  constructor() { super('TestScene'); }

  create(): void {
    const { width, height } = this.scale;
    this.add.rectangle(width / 2, height / 2, width - 56, height - 56).setStrokeStyle(2, 0x927e51);
    this.add.text(width / 2, height / 2 - 40, '成不了仙', { fontFamily: 'sans-serif', fontSize: '64px', color: '#dbc493' }).setOrigin(0.5);
    this.add.text(width / 2, height / 2 + 45, '基础场景 · 初始化完成', { fontFamily: 'sans-serif', fontSize: '28px', color: '#a7b9ae' }).setOrigin(0.5);
  }
}

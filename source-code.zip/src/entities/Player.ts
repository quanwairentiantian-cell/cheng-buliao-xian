import Phaser from 'phaser';

export class Player {
  readonly maxHealth = 100;
  health = this.maxHealth;
  readonly radius = 25;
  private readonly marker: Phaser.GameObjects.Container;
  speed = 220;
  private readonly margin = 32;

  constructor(scene: Phaser.Scene, x: number, y: number) {
    const shadow = scene.add.ellipse(0, 23, 58, 19, 0x000000, 0.4);
    const aura = scene.add.circle(0, 0, 29, 0x8bd8bb, 0.12).setStrokeStyle(1, 0xa5e4ca, 0.6);
    const robe = scene.add.ellipse(0, 7, 39, 44, 0xe2d3ab).setStrokeStyle(2, 0x8b7958);
    const collar = scene.add.triangle(0, 8, 0, 15, -13, -14, 13, -14, 0x55766c);
    const sash = scene.add.rectangle(0, 16, 30, 4, 0x8f7653);
    const hair = scene.add.circle(0, -13, 15, 0x252b29).setStrokeStyle(2, 0x8c805f);
    const knot = scene.add.circle(0, -25, 6, 0x252b29).setStrokeStyle(1, 0xc5ad79);
    const sword = scene.add.rectangle(21, -2, 3, 38, 0xd6e8db).setRotation(0.45);
    this.marker = scene.add.container(x, y, [shadow, aura, robe, collar, sash, hair, knot, sword]);
  }

  get x(): number { return this.marker.x; }
  get y(): number { return this.marker.y; }

  takeDamage(amount: number): void {
    this.health = Math.max(0, this.health - amount);
  }

  move(direction: Phaser.Math.Vector2, deltaMs: number, width: number, height: number): void {
    const distance = this.speed * Math.min(deltaMs, 50) / 1000;
    this.marker.x = Phaser.Math.Clamp(this.marker.x + direction.x * distance, this.margin, width - this.margin);
    this.marker.y = Phaser.Math.Clamp(this.marker.y + direction.y * distance, this.margin, height - this.margin);
  }
}

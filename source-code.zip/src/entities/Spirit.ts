import Phaser from 'phaser';

export class Spirit {
  private readonly marker: Phaser.GameObjects.Arc;
  private readonly expiresAt: number;
  constructor(scene: Phaser.Scene, readonly x: number, readonly y: number, createdAt: number) {
    this.marker = scene.add.circle(x, y, 9, 0x85e8c1).setStrokeStyle(2, 0xd8fff0);
    this.expiresAt = createdAt + 20000;
  }
  update(time: number): boolean {
    const remaining = this.expiresAt - time;
    this.marker.setAlpha(Math.min(1, Math.max(0, remaining / 4000)));
    return remaining > 0;
  }
  destroy(): void { this.marker.destroy(); }
}

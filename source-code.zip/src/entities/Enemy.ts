import Phaser from 'phaser';

export class Enemy {
  readonly radius: number;
  health: number;
  readonly speed: number;
  nextContactAt = 0;
  burnUntil = 0;
  nextBurnAt = 0;
  private chilledUntil = 0;
  private frozenUntil = 0;
  private readonly marker: Phaser.GameObjects.Arc;
  private readonly details: Phaser.GameObjects.Container;
  private readonly color: number;
  private chargeAt = 0;
  private chargeUntil = 0;
  private chargeDirection = new Phaser.Math.Vector2();

  constructor(scene: Phaser.Scene, x: number, y: number, readonly kind: 'normal' | 'fast' | 'heavy' | 'elite' | 'special' | 'boss' = 'normal') {
    const stats = { normal: [22, 2, 85, 0xa34f47], fast: [17, 2, 145, 0xd76558], heavy: [27, 5, 55, 0x76564c], elite: [32, 10, 70, 0xc67b32], special: [21, 5, 65, 0x587ca8], boss: [42, 45, 48, 0x6d3a8c] }[kind];
    [this.radius, this.health, this.speed] = stats;
    this.color = stats[3];
    this.marker = scene.add.circle(x, y, this.radius, this.color).setStrokeStyle(3, 0xe79978);
    const size = this.radius;
    const shadow = scene.add.ellipse(0, size * 0.65, size * 1.9, size * 0.6, 0x000000, 0.35);
    const leftHorn = scene.add.triangle(-size * 0.65, -size * 0.65, 0, size * 0.8, size * 0.35, 0, size * 0.7, size * 0.8, 0x302b29);
    const rightHorn = scene.add.triangle(size * 0.35, -size * 0.65, 0, size * 0.8, size * 0.35, 0, size * 0.7, size * 0.8, 0x302b29);
    const leftEye = scene.add.circle(-size * 0.32, -size * 0.08, Math.max(2, size * 0.11), 0xffdf9c);
    const rightEye = scene.add.circle(size * 0.32, -size * 0.08, Math.max(2, size * 0.11), 0xffdf9c);
    const snout = scene.add.ellipse(0, size * 0.4, size * 0.8, size * 0.35, 0x302b29, 0.6);
    this.details = scene.add.container(x, y, [shadow, leftHorn, rightHorn, leftEye, rightEye, snout]);
    shadow.setDepth(-1);
  }

  get x(): number { return this.marker.x; }
  get y(): number { return this.marker.y; }

  chill(time: number, duration: number): void { this.chilledUntil = Math.max(this.chilledUntil, time + duration); }
  freeze(time: number, duration: number): void { this.frozenUntil = Math.max(this.frozenUntil, time + duration); }

  ignite(time: number): void {
    if (this.burnUntil <= time) this.nextBurnAt = time + 700;
    this.burnUntil = time + 2100;
    this.marker.setFillStyle(0xe88637);
  }

  updateBurn(time: number): boolean {
    if (this.burnUntil === 0) return false;
    if (time >= this.nextBurnAt && this.nextBurnAt <= this.burnUntil) {
      this.nextBurnAt += 700;
      return true;
    }
    if (time > this.burnUntil) {
      this.burnUntil = 0;
      this.marker.setFillStyle(this.color);
    }
    return false;
  }

  chase(x: number, y: number, delta: number, time: number): void {
    this.details.setPosition(this.marker.x, this.marker.y);
    this.marker.setStrokeStyle(3, time < this.frozenUntil ? 0xe4ffff : time < this.chilledUntil ? 0x80dfff : 0xe79978);
    if (time < this.frozenUntil) return;
    const slow = time < this.chilledUntil ? 0.6 : 1;
    if (this.kind === 'special') {
      if (this.chargeAt === 0) this.chargeAt = time + 2500;
      if (time >= this.chargeAt && this.chargeUntil === 0) {
        this.chargeDirection.set(x - this.x, y - this.y).normalize();
        this.chargeUntil = time + 500;
        this.chargeAt = time + 3500;
      }
      if (this.chargeUntil > time) {
        this.marker.x += this.chargeDirection.x * 300 * slow * Math.min(delta, 50) / 1000;
        this.marker.y += this.chargeDirection.y * 300 * slow * Math.min(delta, 50) / 1000;
        return;
      }
      this.chargeUntil = 0;
    }
    const direction = new Phaser.Math.Vector2(x - this.x, y - this.y);
    if (direction.lengthSq() > 0) {
      direction.normalize().scale(this.speed * slow * Math.min(delta, 50) / 1000);
      this.marker.x += direction.x;
      this.marker.y += direction.y;
    }
  }

  destroy(): void { this.marker.destroy(); this.details.destroy(); }
}

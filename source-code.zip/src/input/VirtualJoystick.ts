import Phaser from 'phaser';

export class VirtualJoystick {
  private readonly center = new Phaser.Math.Vector2(120, 1135);
  private readonly radius = 75;
  private readonly knob: Phaser.GameObjects.Arc;
  private pointerId: number | null = null;
  readonly direction = new Phaser.Math.Vector2();

  constructor(private readonly scene: Phaser.Scene) {
    scene.add.circle(this.center.x, this.center.y, this.radius, 0xa8bcae, 0.12).setStrokeStyle(2, 0xa8bcae, 0.5);
    this.knob = scene.add.circle(this.center.x, this.center.y, 30, 0xd9c796, 0.65);
    scene.input.on('pointerdown', this.onDown, this);
    scene.input.on('pointermove', this.onMove, this);
    scene.input.on('pointerup', this.onUp, this);
    scene.input.on('pointerupoutside', this.onUp, this);
    scene.game.events.on(Phaser.Core.Events.BLUR, this.reset, this);
    scene.events.once(Phaser.Scenes.Events.SHUTDOWN, this.destroy, this);
  }

  private onDown(pointer: Phaser.Input.Pointer): void {
    if (this.pointerId !== null || Phaser.Math.Distance.Between(pointer.x, pointer.y, this.center.x, this.center.y) > this.radius + 30) return;
    this.pointerId = pointer.id;
    this.updatePointer(pointer);
  }

  private onMove(pointer: Phaser.Input.Pointer): void {
    if (pointer.id === this.pointerId && pointer.isDown) this.updatePointer(pointer);
  }

  private onUp(pointer: Phaser.Input.Pointer): void {
    if (pointer.id === this.pointerId) this.reset();
  }

  private updatePointer(pointer: Phaser.Input.Pointer): void {
    this.direction.set(pointer.x - this.center.x, pointer.y - this.center.y).limit(this.radius);
    this.knob.setPosition(this.center.x + this.direction.x, this.center.y + this.direction.y);
    this.direction.scale(1 / this.radius);
  }

  reset(): void {
    this.pointerId = null;
    this.direction.set(0, 0);
    this.knob.setPosition(this.center.x, this.center.y);
  }

  private destroy(): void {
    this.scene.input.off('pointerdown', this.onDown, this);
    this.scene.input.off('pointermove', this.onMove, this);
    this.scene.input.off('pointerup', this.onUp, this);
    this.scene.input.off('pointerupoutside', this.onUp, this);
    this.scene.game.events.off(Phaser.Core.Events.BLUR, this.reset, this);
  }
}

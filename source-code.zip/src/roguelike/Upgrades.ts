export interface Upgrade {
  name: string;
  description: string;
  apply: () => void;
}

export function chooseUpgrades(options: Upgrade[]): Upgrade[] {
  const pool = [...options];
  const choices: Upgrade[] = [];
  while (choices.length < 3 && pool.length) {
    const index = Math.floor(Math.random() * pool.length);
    const choice = pool[index];
    choices.push(choice);
    for (let poolIndex = pool.length - 1; poolIndex >= 0; poolIndex--) {
      if (pool[poolIndex].name === choice.name) pool.splice(poolIndex, 1);
    }
  }
  return choices;
}

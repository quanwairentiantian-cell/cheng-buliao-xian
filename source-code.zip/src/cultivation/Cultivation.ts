export type Fate = '逆天而行' | '聚灵之体' | '轮回残魂' | '天煞孤星' | '天生道体';
export type Root = '雷灵根' | '火灵根';

export class Cultivation {
  readonly fate: Fate;
  readonly root: Root = Math.random() < 0.5 ? '雷灵根' : '火灵根';
  realm = '凡人';
  attention = 0;
  breakthrough = false;

  constructor(lives = 0) {
    const fates: Fate[] = ['逆天而行', '聚灵之体', '天煞孤星', '天生道体'];
    if (lives >= 2) fates.push('轮回残魂');
    this.fate = fates[Math.floor(Math.random() * fates.length)];
  }

  addAttention(amount: number): void {
    this.attention = Math.min(100, this.attention + amount * (this.fate === '逆天而行' ? 2 : 1));
  }
}
